@echo off
echo 正在导入数据库，请稍候...


set mysql_path="C:\Program Files\MySQL\MySQL Server 8.0\bin"
set db_name=telecom_churn
set sql_file=telecom_churn.sql


%mysql_path%\mysql -u root -p < %sql_file%

echo 导入完成！
pause